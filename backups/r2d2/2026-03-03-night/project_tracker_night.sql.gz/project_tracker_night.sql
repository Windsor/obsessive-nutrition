--
-- PostgreSQL database dump
--

\restrict BVF6l9XpfjNIoeceWrBQkBQy1FzaU9SyMFXK3a7B0SErmCtApCzdE7qjVoyZNMJ

-- Dumped from database version 17.8 (Ubuntu 17.8-1.pgdg22.04+1)
-- Dumped by pg_dump version 17.8 (Ubuntu 17.8-1.pgdg22.04+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: artifacts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.artifacts (
    id integer NOT NULL,
    project_id integer,
    task_id integer,
    filename character varying(500) NOT NULL,
    original_name character varying(500),
    file_type character varying(50),
    file_size bigint,
    mime_type character varying(100),
    category character varying(50) DEFAULT 'file'::character varying,
    description text,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.artifacts OWNER TO postgres;

--
-- Name: artifacts_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.artifacts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.artifacts_id_seq OWNER TO postgres;

--
-- Name: artifacts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.artifacts_id_seq OWNED BY public.artifacts.id;


--
-- Name: commands; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.commands (
    id integer NOT NULL,
    type character varying(50) DEFAULT 'chat'::character varying NOT NULL,
    message text NOT NULL,
    context jsonb DEFAULT '{}'::jsonb,
    status character varying(20) DEFAULT 'pending'::character varying,
    response text,
    created_at timestamp without time zone DEFAULT now(),
    responded_at timestamp without time zone,
    user_name character varying(100) DEFAULT 'Glenn'::character varying
);


ALTER TABLE public.commands OWNER TO postgres;

--
-- Name: commands_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.commands_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.commands_id_seq OWNER TO postgres;

--
-- Name: commands_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.commands_id_seq OWNED BY public.commands.id;


--
-- Name: projects; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.projects (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    status character varying(50) DEFAULT 'active'::character varying,
    priority character varying(20) DEFAULT 'medium'::character varying,
    progress integer DEFAULT 0,
    category character varying(100),
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.projects OWNER TO postgres;

--
-- Name: projects_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.projects_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.projects_id_seq OWNER TO postgres;

--
-- Name: projects_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.projects_id_seq OWNED BY public.projects.id;


--
-- Name: status_updates; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.status_updates (
    id integer NOT NULL,
    project_id integer,
    content text NOT NULL,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.status_updates OWNER TO postgres;

--
-- Name: status_updates_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.status_updates_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.status_updates_id_seq OWNER TO postgres;

--
-- Name: status_updates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.status_updates_id_seq OWNED BY public.status_updates.id;


--
-- Name: tasks; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tasks (
    id integer NOT NULL,
    project_id integer,
    title character varying(500) NOT NULL,
    description text,
    status character varying(50) DEFAULT 'todo'::character varying,
    priority character varying(20) DEFAULT 'medium'::character varying,
    due_date date,
    created_at timestamp without time zone DEFAULT now(),
    completed_at timestamp without time zone
);


ALTER TABLE public.tasks OWNER TO postgres;

--
-- Name: tasks_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tasks_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.tasks_id_seq OWNER TO postgres;

--
-- Name: tasks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tasks_id_seq OWNED BY public.tasks.id;


--
-- Name: artifacts id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.artifacts ALTER COLUMN id SET DEFAULT nextval('public.artifacts_id_seq'::regclass);


--
-- Name: commands id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.commands ALTER COLUMN id SET DEFAULT nextval('public.commands_id_seq'::regclass);


--
-- Name: projects id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.projects ALTER COLUMN id SET DEFAULT nextval('public.projects_id_seq'::regclass);


--
-- Name: status_updates id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.status_updates ALTER COLUMN id SET DEFAULT nextval('public.status_updates_id_seq'::regclass);


--
-- Name: tasks id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tasks ALTER COLUMN id SET DEFAULT nextval('public.tasks_id_seq'::regclass);


--
-- Data for Name: artifacts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.artifacts (id, project_id, task_id, filename, original_name, file_type, file_size, mime_type, category, description, created_at) FROM stdin;
22	3	\N	project-3/concept1-doorway.png	concept1-doorway.png	image	9323912	image/png	file	Cover image: concept1-doorway.png	2026-02-13 17:33:33.734323
23	3	\N	project-3/concept2-hand.png	concept2-hand.png	image	8939557	image/png	file	Cover image: concept2-hand.png	2026-02-13 17:33:33.780796
24	3	\N	project-3/concept3-staircase.png	concept3-staircase.png	image	9939851	image/png	file	Cover image: concept3-staircase.png	2026-02-13 17:33:33.825966
31	3	\N	project-3/doorway-upscale.png	doorway-upscale.png	image	2212769	image/png	file	Upscaled: Doorway cover	2026-02-13 17:33:34.135636
32	3	\N	project-3/grip-tiles-grid.png	grip-tiles-grid.png	image	9486466	image/png	file	Cover image: grip-tiles-grid.png	2026-02-13 17:33:34.179448
34	3	\N	project-3/hand-upscale.png	hand-upscale.png	image	2398005	image/png	file	Upscaled: Hand cover	2026-02-13 17:33:34.268684
35	3	\N	project-3/intertwined-hands-grid.png	intertwined-hands-grid.png	image	9295854	image/png	file	Cover image: intertwined-hands-grid.png	2026-02-13 17:33:34.316588
37	3	\N	project-3/staircase-upscale.png	staircase-upscale.png	image	2331810	image/png	file	Upscaled: Staircase cover	2026-02-13 17:33:34.409842
38	3	\N	project-3/two-silhouettes-grid.png	two-silhouettes-grid.png	image	7432120	image/png	file	Cover image: two-silhouettes-grid.png	2026-02-13 17:33:34.445074
40	3	\N	project-3/woman-against-wall-grid.png	woman-against-wall-grid.png	image	8863037	image/png	file	Cover image: woman-against-wall-grid.png	2026-02-13 17:33:34.516187
1	1	39	project-1/series-bible.md	series-bible.md	text	14289	text/markdown	file	Douro Dynasty 4-book series bible	2026-02-13 17:33:32.162624
2	1	41	project-1/book1.md	CRUSH-book1.md	text	300738	text/markdown	file	Book 1 manuscript ~53k words	2026-02-13 17:33:32.208277
3	1	43	project-1/marketing.md	marketing.md	text	9632	text/markdown	file	Marketing package - blurbs, keywords, strategy	2026-02-13 17:33:32.255833
4	1	42	project-1/crush-complete.docx	crush-complete.docx	document	159592	application/vnd.openxmlformats-officedocument.wordprocessingml.document	file	CRUSH manuscript .docx export	2026-02-13 17:33:32.29829
5	1	42	project-1/crush-book1.docx	crush-book1.docx	document	127689	application/vnd.openxmlformats-officedocument.wordprocessingml.document	file	CRUSH manuscript .docx export	2026-02-13 17:33:32.341021
7	2	49	project-2/genre-analysis.md	genre-analysis.md	text	35506	text/markdown	file	Genre analysis - 4 monster romance comps	2026-02-13 17:33:32.432403
6	2	50	project-2/series-bible.md	series-bible.md	text	25504	text/markdown	file	7-book series bible - Portuguese mythology	2026-02-13 17:33:32.385462
8	2	51	project-2/book1-ch1-10.md	book1-ch1-10.md	text	116283	text/markdown	file	Chapters 1-10	2026-02-13 17:33:32.468147
9	2	52	project-2/book1-ch11-20.md	book1-ch11-20.md	text	109368	text/markdown	file	Chapters 11-20	2026-02-13 17:33:32.502465
10	2	53	project-2/book1-act4-5.md	book1-act4-5.md	text	151004	text/markdown	file	Chapters 21-30 + epilogue	2026-02-13 17:33:32.536259
11	2	54	project-2/book1-final.md	ENCANTADA-final.md	text	376371	text/markdown	file	Complete assembled manuscript ~65k words	2026-02-13 17:33:32.576242
13	2	55	project-2/ENCANTADA.docx	ENCANTADA.docx	document	189543	application/vnd.openxmlformats-officedocument.wordprocessingml.document	file	Final manuscript .docx export	2026-02-13 17:33:32.642899
12	2	56	project-2/marketing.md	marketing.md	text	12925	text/markdown	file	Marketing package	2026-02-13 17:33:32.60847
14	3	60	project-3/series-bible.md	series-bible.md	text	23122	text/markdown	file	5-book literary erotica series bible	2026-02-13 17:33:32.678956
15	3	61	project-3/book1-part1.md	book1-part1.md	text	112638	text/markdown	file	THE SALON chapters 1-7	2026-02-13 17:33:32.724653
16	3	62	project-3/book1-part2.md	book1-part2.md	text	157791	text/markdown	file	THE SALON chapters 8-14	2026-02-13 17:33:32.767219
17	3	63	project-3/book1-part3.md	book1-part3.md	text	97094	text/markdown	file	THE SALON chapters 15-20	2026-02-13 17:33:32.810875
18	3	64	project-3/book1-final.md	THE-SALON-final.md	text	367410	text/markdown	file	Complete assembled manuscript ~64k words	2026-02-13 17:33:32.859055
20	3	65	project-3/THE_FIFTH_FLOOR.docx	THE_FIFTH_FLOOR.docx	document	172271	application/vnd.openxmlformats-officedocument.wordprocessingml.document	file	Final manuscript .docx export	2026-02-13 17:33:32.944725
19	3	66	project-3/marketing.md	marketing.md	text	14483	text/markdown	file	Marketing package + cross-promotion strategy	2026-02-13 17:33:32.89962
21	3	72	project-3/THE_FIFTH_FLOOR_Marketing.pdf	THE_FIFTH_FLOOR_Marketing.pdf	pdf	532782	application/pdf	file	Marketing PDF	2026-02-13 17:33:32.989471
25	3	67	project-3/cover-A-doorway.jpg	cover-A-doorway.jpg	image	1215075	image/jpeg	file	Cover A: Doorway concept	2026-02-13 17:33:33.866114
26	3	67	project-3/cover-B-staircase.jpg	cover-B-staircase.jpg	image	1238517	image/jpeg	file	Cover B: Staircase concept	2026-02-13 17:33:33.908842
30	3	67	project-3/cover-C-hand.jpg	cover-C-hand.jpg	image	1270483	image/jpeg	file	Cover C: Hand on tiles	2026-02-13 17:33:34.090887
27	3	67	project-3/cover-C2-woman-wall.jpg	cover-C2-woman-wall.jpg	image	1000833	image/jpeg	file	Cover C2: Woman against wall	2026-02-13 17:33:33.955056
28	3	67	project-3/cover-C3-grip.jpg	cover-C3-grip.jpg	image	1028409	image/jpeg	file	Cover C3: Grip on tiles	2026-02-13 17:33:34.002112
29	3	67	project-3/cover-C4-two-women.jpg	cover-C4-two-women.jpg	image	811814	image/jpeg	file	Cover C4: Two silhouettes	2026-02-13 17:33:34.049656
33	3	68	project-3/grip-up.png	grip-up.png	image	2087154	image/png	file	Upscaled: Grip cover	2026-02-13 17:33:34.225176
39	3	68	project-3/wall-up.png	wall-up.png	image	2088319	image/png	file	Upscaled: Wall cover	2026-02-13 17:33:34.480169
36	3	68	project-3/silhouettes-up.png	silhouettes-up.png	image	1475501	image/png	file	Upscaled: Silhouettes cover	2026-02-13 17:33:34.363157
41	6	92	project-6/escalate-game.html	escalate-game.html	html	50427	text/html	file	Complete party game - single HTML file	2026-02-13 17:33:34.550625
42	8	105	project-8/genre-analysis.md	genre-analysis.md	text	32324	text/markdown	file	Dark romance genre analysis - 3 bestsellers	2026-02-13 17:33:34.576692
43	8	106	project-8/cruel-obsession.md	cruel-obsession.md	text	1304	text/markdown	file	Full novella manuscript	2026-02-13 17:33:34.608236
44	8	106	project-8/Cruel_Obsession_-_The_Obsession_Duet_Book_1.docx	Cruel_Obsession.docx	document	94961	application/vnd.openxmlformats-officedocument.wordprocessingml.document	file	Novella .docx export	2026-02-13 17:33:34.639397
45	3	\N	project-3/cover-virginia-doorway.png	cover-virginia-doorway.png	image	9258149	image/png	file		2026-02-14 14:17:36.694948
46	3	\N	project-3/cover-virginia-azulejo.png	cover-virginia-azulejo.png	image	8814548	image/png	file		2026-02-14 14:17:37.119854
\.


--
-- Data for Name: commands; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.commands (id, type, message, context, status, response, created_at, responded_at, user_name) FROM stdin;
1	chat	hey Saturday, this working?	{}	done	Hey Glenn! Yes, Command Center is live and working. I just picked up your message. I'll be checking for new commands on every heartbeat from now on. Try any of the quick actions or just chat — I'm here. ☕	2026-02-13 17:47:36.53654	2026-02-13 17:48:48.613204	Glenn
2	chat	My wife will also be using this project tracker, so she will be interfacing with you as well, please add a user selection/login.  It doesn't need to be secure, since its just my wife and I on a private network	{}	done	On it! Adding a simple user picker (Glenn / Wife) — no passwords, just click to identify. Will update all commands and messages with the user name so I know who I'm talking to. Give me a minute to build it. ☕	2026-02-13 17:49:52.036056	2026-02-13 17:52:12.154839	Glenn
3	chat	hello, can you tell who I am?	{}	done	Hey Glenn! 👨‍💻 Yep, I can see it's you. The user profiles are working perfectly. Virginia will show up as 👩 when she uses it. Response time: ~1 minute via the cron poll. What's next?	2026-02-13 17:55:49.797296	2026-02-13 17:56:10.450658	Glenn
4	task	Task started: "Re-enable LaunchAgent" (Project: Samsung Frame TV Dashboard). Please work on this.\nContext: Paused per Glenn's request — unloaded	{"task_id": 104, "project_id": 7, "task_title": "Re-enable LaunchAgent", "project_name": "Samsung Frame TV Dashboard"}	done	Done! LaunchAgent com.openclaw.frame-dashboard is loaded and running (PID 6196). The dashboard will update every 15 minutes during active hours (7am-10pm). TV IP: 192.168.68.151.	2026-02-13 18:05:45.724695	2026-02-13 18:07:33.823087	Glenn
5	chat	please add the project tracker url to heimdall	{}	done	I can't add to Heimdall directly — it's a GUI-only dashboard with no API. You'll need to add it manually:\n\n1. Go to http://192.168.68.139 (Heimdall)\n2. Click the + button to add a new app\n3. Name: Project Tracker\n4. URL: http://192.168.68.139:3001\n5. Pick a color/icon you like\n\nWhile you're there, you might also add:\n- Adult Directory: http://192.168.68.139:3000\n- Command Center: http://192.168.68.139:3001/command-center\n- Services Directory: http://192.168.68.139:3001/services	2026-02-13 18:09:42.350814	2026-02-13 18:10:37.207102	Glenn
6	chat	Please reimagine the covers for the book, “The Fifth Floor”, specifically, A (woman in doorway). This picture must include blue azulejos and the doors should fit the doorframe so it looks as though they fit. Please keep the old Portuguese style for the architecture. Next, please redo the cover with a young woman leaning against the azulejos in a blissfull form. Again, please keep the overall Portuguese asthmatic.	{}	done	Hi Virginia! I've submitted both cover requests to Midjourney:\n\n1. **Doorway cover** — Woman in an ornate Portuguese doorway with blue/white azulejos, properly fitted wooden doors, old Portuguese colonial architecture\n2. **Azulejo wall cover** — Young woman leaning blissfully against blue/white azulejo tiles, dreamy and serene, Portuguese aesthetic\n\nBoth are generating now in relax mode (takes ~5-10 min). I'll send the image grids to Glenn's WhatsApp as soon as they're ready!	2026-02-14 09:41:33.395788	2026-02-14 09:45:28.745517	Virginia
7	task	Task started: "Domain + Cloudflare Tunnel" (Project: Portugal News Newsletter). Please work on this.\nContext: Waiting on Glenn to get .pt domain. Then set up Cloudflare Tunnel for public access.	{"task_id": 129, "project_id": 10, "task_title": "Domain + Cloudflare Tunnel", "project_name": "Portugal News Newsletter"}	done	Domain + Cloudflare Tunnel — theportugalbrief.pt is already live via Cloudflare! Domain is set up, Ghost is accessible at https://theportugalbrief.pt, and the admin at /ghost/. This task was completed previously. Marking as done.	2026-02-20 16:12:54.275151	2026-02-20 16:16:35.949714	Glenn
8	task	Task started: "Mailgun email setup" (Project: Portugal News Newsletter). Please work on this.\nContext: Configure Mailgun for newsletter email delivery (EU region, SPF/DKIM/DMARC)	{"task_id": 130, "project_id": 10, "task_title": "Mailgun email setup", "project_name": "Portugal News Newsletter"}	done	Mailgun email setup — We actually set up Brevo SMTP on Feb 18 instead of Mailgun (Mailgun was $15/mo, Brevo is free at 300 emails/day). Brevo is already configured in Ghost. Glenn is currently looking at switching to Mailgun — waiting on his decision about whether to proceed or stick with Brevo.	2026-02-20 16:13:25.553257	2026-02-20 16:16:42.784306	Glenn
\.


--
-- Data for Name: projects; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.projects (id, name, description, status, priority, progress, category, created_at, updated_at) FROM stdin;
13	Obsessive Nutrition	Science-first KDP book series — deep dives into superfoods and health topics. Domain: obsessivenutrition.com. Books done: Sardines, Olive Oil. Website + blog to come.	active	medium	0	publishing	2026-03-03 23:17:19.422509	2026-03-03 23:17:26.574656
4	Adult Directory Portugal	Adult services directory website for Portugal. Flask backend + static frontend, 36 real businesses, Leaflet map, Claude-powered 'Add Listing' via URL parsing.	active	medium	90	Tech	2026-02-13 17:20:49.145514	2026-02-13 20:05:34.348349
8	Cruel Obsession (Novella)	Dark romance novella set in Lisbon. Billionaire Aleksandr Volkov + art curator Sofia Marques. Complete.	completed	low	100	Writing	2026-02-13 17:20:49.930773	2026-02-13 17:25:59.387353
3	The Fifth Floor (Literary Erotica)	5-book literary erotica series set in a secret society in Lisbon's Alfama district. Anne Rice Sleeping Beauty level explicitness. Book 1 (THE SALON) complete at ~64k words. Pen name: Ruby Saudade.	active	high	20	Writing	2026-02-13 17:20:48.731349	2026-02-13 17:27:38.946584
1	Douro Dynasty (CRUSH)	4-book dark romance series set in Douro Valley wine country + Porto. Book 1 (CRUSH) complete at ~53k words, 25 chapters.	active	high	25	Writing	2026-02-13 17:20:48.230186	2026-02-13 17:25:57.603727
12	Obsessive Nutrition	Science-first nutrition book series. KDP self-publishing + SEO blog. Single-food deep dives for health obsessives.	active	high	0	Content / Publishing	2026-03-03 23:12:51.780186	2026-03-03 23:13:00.572787
5	Project Tracker	Project and status tracking system. Flask + PostgreSQL, deployed on Ubuntu server.	completed	medium	100	Tech	2026-02-13 17:20:49.412126	2026-02-28 01:07:58.209595
10	Portugal News Newsletter	English-language political news and analysis newsletter for Portugal expat community. Freemium subscription model with sponsorships.	active	medium	0		2026-02-18 08:42:34.475308	2026-03-03 23:13:08.651565
7	Samsung Frame TV Dashboard	Auto-updating dashboard for Samsung Frame TV showing time, weather, crypto, markets, and news headlines. LaunchAgent on Mac mini.	active	low	100	Tech	2026-02-13 17:20:49.784548	2026-02-13 18:07:33.92452
6	Escalate (Party Game)	Adult swinger party card/dice game as a single HTML file web app. 83 cards, 5 levels, dice, timer, voting, gender/orientation matching, stripping mechanic.	paused	low	90	Tech	2026-02-13 17:20:49.636462	2026-02-13 17:25:59.15636
2	ENCANTADA (A Moura's Claim)	7-book monster romance series rooted in Portuguese mythology (Mouros Encantados). Book 1 complete at ~65k words, 30 chapters + epilogue. American heroines, shapeshifting serpent heroes.	active	high	15	Writing	2026-02-13 17:20:48.411983	2026-02-13 17:25:57.966696
9	Quiz Video Generator	Automated quiz/trivia video generator for YouTube & TikTok. Web UI, ElevenLabs TTS, ffmpeg pipeline. Deployable on Ubuntu server.	active	medium	100		2026-02-14 14:12:57.345163	2026-02-21 23:34:55.226845
11	Daily Finance Pulse	Automated financial newsletter — crypto, equities, forex, commodities, macro. Ghost CMS on port 2370.	active	high	0	newsletter	2026-02-20 23:10:00.153908	2026-03-03 03:10:17.342296
\.


--
-- Data for Name: status_updates; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.status_updates (id, project_id, content, created_at) FROM stdin;
1	1	Book 1 complete and delivered as .docx. Marketing package done. Awaiting Glenn's feedback before proceeding to Book 2.	2026-02-13 17:20:48.385598
2	2	Book 1 complete and delivered as ENCANTADA.docx. Marketing package done. Awaiting feedback.	2026-02-13 17:20:48.693789
3	3	Book 1 complete and delivered. 6 cover options generated and sent. Glenn likes doorway (A) and hand/tiles/silhouettes (C variants). Marketing PDF blocked by Unicode issue.	2026-02-13 17:20:49.107763
4	4	Deployed to Ubuntu server r2d2 on port 3000. GitHub repo: Windsor/adult-directory-portugal (private). Systemd service enabled.	2026-02-13 17:20:49.376755
5	5	Built and deployed. Running on r2d2:3001 with PostgreSQL backend.	2026-02-13 17:20:49.598645
6	6	Fully functional single-page app. Not yet deployed publicly.	2026-02-13 17:20:49.747582
7	7	Paused per Glenn's request. LaunchAgent unloaded. TV IP: 192.168.68.151.	2026-02-13 17:20:49.892725
8	8	Complete. Used as a learning exercise before the main series.	2026-02-13 17:20:50.039253
9	4	Complete frontend redesign deployed — dark theme, worldwide support, search/filter by category/country/city, grid+map views. All 36 listings now have country fields. Pushed to GitHub.	2026-02-13 18:07:12.964842
10	7	LaunchAgent re-enabled and running. Dashboard updating every 15 min.	2026-02-13 18:07:33.889439
11	10	Night Shift Block 2: Project Tracker upgraded with analytics dashboard (search, activity feed, velocity chart, priority/category breakdowns). New API endpoints: /api/activity, /api/search, /api/stats/detailed.	2026-02-20 01:02:42.285596
12	10	Night Shift Block 2 (continued): About page created, 6 tag descriptions + SEO meta added, Ghost site meta/OG/Twitter tags set, navigation updated, newsletter template improved with feedback + footer.	2026-02-20 01:07:54.616849
13	10	Night shift complete: 18 tasks across 4 blocks. SEO, infrastructure, social poster, dashboard, content templates, documentation, memory management all done. Blocked: GitHub auth, Mastodon creds, GSC verification, Twitter/LinkedIn keys, Mailgun.	2026-02-20 05:00:57.577054
14	10	Internal linking: 49 PT Brief + 5 Finance articles: Created related-posts.py. Adds Related Stories/Analysis sections based on shared tags. Improves SEO via internal linking.	2026-02-25 03:06:45.702938
15	10	Weekly digest generator updated: Fixed bug in weekly-digest.py. Generates top 10 curated stories from past week. Cron runs Sundays 10am.	2026-02-25 03:06:45.755302
16	10	Sitemap ping tool — Google/Bing endpoints deprecated: Created sitemap-ping.py. Discovered Google/Bing deprecated ping endpoints. Need IndexNow or Search Console API.	2026-02-25 03:06:45.813142
17	11	Clip pipeline quality audit — 1080p 30fps H264 verified: Audited video pipeline output: 1920x1080, 30fps, H264+AAC, 11-13MB, 2min clips. Quality sources (Bloomberg, WSJ, CBS).	2026-02-25 03:06:45.873916
21	10	Night shift Block 1 health check — all 5 services active, disk 90%, 9GB RAM free, 0 errors. PT Brief 83 posts, Finance 17 posts. Offsite backup pulled.	2026-02-25 23:12:47.001492
22	11	Finance Video V2 renderer — Major visual upgrade: glassmorphism cards, animated particles, Fear & Greed gauge, highlighted numbers, scrolling ticker, crypto logos, scene transitions. Quality ~35% → ~80%.	2026-02-25 23:12:59.324253
23	11	Fixed missing meta_title/custom_excerpt on today's Deep Dive + Market Analysis. Fixed update_ghost_post() to set meta fields on updates.	2026-02-25 23:12:59.361593
24	11	Downloaded high-res crypto logos (BTC/ETH/SOL/XRP/ADA/DOGE) from cryptologos.cc. Synced finance-video-v2 pipeline to r2d2.	2026-02-25 23:12:59.397471
25	10	IndexNow URL submission tool created (tools/ghost-publisher/indexnow.py). Generates key, submits URLs to Bing/Yandex for faster indexing. Needs Glenn to place verification file on theportugalbrief.pt.	2026-02-25 23:16:09.971866
26	10	Night shift: memory maintenance — archived Feb 21-22 daily files to week3 summary. MEMORY.md updated with finance video v2 details.	2026-02-25 23:16:10.009554
27	11	Video V2: Added sparkline charts to data cards + anti-aliased Fear & Greed gauge + crypto logos synced to r2d2. Quality ~9/10 on crypto cards.	2026-02-26 01:15:18.743908
28	10	Member growth tools: member-growth.py created (stats, audit, CTA injection). Subscribe CTAs injected into 82/83 PT Brief + 16/17 Finance posts. Social sharing audit: only minor title length issues.	2026-02-26 01:15:25.157477
29	11	Title card v3: glassmorphism stat cards, animated pulse line, count-up animation, change percentages. Quality 5.5→7.5/10.	2026-02-26 03:07:49.949573
30	10	Content analytics dashboard created. Fixed 2 finance posts missing fields. All 83 PT Brief + 17 Finance posts now healthy.	2026-02-26 03:07:50.001371
\.


--
-- Data for Name: tasks; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tasks (id, project_id, title, description, status, priority, due_date, created_at, completed_at) FROM stdin;
39	1	Write series bible	projects/douro-dynasty/series-bible.md — 4-book series plan, characters, world-building	done	high	\N	2026-02-13 17:25:57.344708	\N
40	1	Genre analysis — dark romance comps	projects/cruel-obsession/genre-analysis.md — Lipińska, Douglas, Huang analyzed	done	medium	\N	2026-02-13 17:25:57.382669	\N
41	1	Write Book 1 (CRUSH) — 25 chapters, ~53k words	projects/douro-dynasty/book1.md	done	high	\N	2026-02-13 17:25:57.40968	\N
42	1	Export CRUSH as .docx	Delivered via WhatsApp as CRUSH.docx	done	medium	\N	2026-02-13 17:25:57.445528	\N
43	1	Create marketing package	projects/douro-dynasty/marketing.md — blurbs, keywords, categories, KU strategy, social copy	done	medium	\N	2026-02-13 17:25:57.471884	\N
44	1	Glenn reviews CRUSH manuscript	Awaiting feedback	in_progress	high	\N	2026-02-13 17:25:57.497738	\N
45	1	Generate book cover for CRUSH	Midjourney via GoAPI — same pipeline as Fifth Floor covers	todo	high	\N	2026-02-13 17:25:57.523911	\N
46	1	Write Book 2 (FERMENT)	Next in series — Mateus & Clara	todo	medium	\N	2026-02-13 17:25:57.550115	\N
47	1	Write Book 3 (DECANT)	\N	todo	low	\N	2026-02-13 17:25:57.573322	\N
48	1	Write Book 4 (BLEND)	\N	todo	low	\N	2026-02-13 17:25:57.599987	\N
49	2	Genre analysis — 4 monster romance comps	projects/monster-romance/genre-analysis.md — Grace Draven, Sarah J. Maas, Zoey Draven, Ruby Dixon	done	medium	\N	2026-02-13 17:25:57.62642	\N
50	2	Write series bible — 7-book plan	projects/monster-romance/series-bible.md — Portuguese mythology, Mouros Encantados, 7 noble houses	done	high	\N	2026-02-13 17:25:57.650463	\N
51	2	Write Book 1 ch1-10	projects/monster-romance/book1-ch1-10.md	done	high	\N	2026-02-13 17:25:57.684523	\N
52	2	Write Book 1 ch11-20	projects/monster-romance/book1.md	done	high	\N	2026-02-13 17:25:57.711165	\N
53	2	Write Book 1 ch21-30 + epilogue	projects/monster-romance/book1-act4-5.md	done	high	\N	2026-02-13 17:25:57.736205	\N
54	2	Assemble final manuscript — ~65k words	projects/monster-romance/book1-final.md	done	high	\N	2026-02-13 17:25:57.773604	\N
55	2	Export ENCANTADA as .docx	Delivered via WhatsApp as ENCANTADA.docx	done	medium	\N	2026-02-13 17:25:57.810788	\N
56	2	Create marketing package	projects/monster-romance/marketing.md — blurbs, keywords, categories, social copy	done	medium	\N	2026-02-13 17:25:57.847628	\N
57	2	Glenn reviews ENCANTADA manuscript	Awaiting feedback	in_progress	high	\N	2026-02-13 17:25:57.886197	\N
58	2	Generate book cover for ENCANTADA	Midjourney via GoAPI	todo	high	\N	2026-02-13 17:25:57.923752	\N
59	2	Write Book 2 (MARÉ) — Jade + Rui	\N	todo	medium	\N	2026-02-13 17:25:57.961157	\N
60	3	Write series bible — 5-book plan	projects/erotica-series/series-bible.md — 5 floors, secret society in Alfama, Lisbon	done	high	\N	2026-02-13 17:25:57.99857	\N
61	3	Write Book 1 Part 1 (ch1-7)	projects/erotica-series/book1-part1.md	done	high	\N	2026-02-13 17:25:58.037279	\N
62	3	Write Book 1 Part 2 (ch8-14)	projects/erotica-series/book1-part2.md	done	high	\N	2026-02-13 17:25:58.074556	\N
63	3	Write Book 1 Part 3 (ch15-20)	projects/erotica-series/book1-part3.md	done	high	\N	2026-02-13 17:25:58.113063	\N
64	3	Assemble THE SALON — ~64k words, 20 chapters	projects/erotica-series/book1-final.md	done	high	\N	2026-02-13 17:25:58.149526	\N
65	3	Export as .docx	Delivered via WhatsApp as THE_FIFTH_FLOOR.docx	done	medium	\N	2026-02-13 17:25:58.187329	\N
66	3	Create marketing package	projects/erotica-series/marketing.md — blurbs, keywords, cross-promotion strategy across all 3 series	done	medium	\N	2026-02-13 17:25:58.225641	\N
67	3	Generate 6 cover concepts via Midjourney	projects/erotica-series/covers/ — doorway, grip, tiles, silhouettes, wall, corridor variants	done	high	\N	2026-02-13 17:25:58.26338	\N
68	3	Upscale selected covers (wall, grip, silhouettes)	projects/erotica-series/covers/*-up.png	done	medium	\N	2026-02-13 17:25:58.301376	\N
69	3	Send all 6 covers to Glenn	Sent via WhatsApp	done	medium	\N	2026-02-13 17:25:58.327171	\N
70	3	Glenn reviews THE SALON manuscript	Awaiting feedback	in_progress	high	\N	2026-02-13 17:25:58.347577	\N
72	3	Fix marketing PDF — Unicode encoding issue	fpdf2 FPDFUnicodeEncodingException with em-dash. Fix: replace Unicode or use TTF font	todo	medium	\N	2026-02-13 17:25:58.394272	\N
73	3	Generate marketing PDF for Glenn's wife	Multi-page PDF: blurbs, taglines, comps, covers, strategy	todo	medium	\N	2026-02-13 17:25:58.417729	\N
74	3	Write Book 2 (THE GARDEN) — James + Sebastião, M/M	\N	todo	medium	\N	2026-02-13 17:25:58.442822	\N
75	4	Research 36 real adult businesses in Portugal	projects/adult-directory/research.md + data/listings.json	done	high	\N	2026-02-13 17:25:58.467399	\N
76	4	Build Flask backend with API endpoints	projects/adult-directory/server.py — parse-url, add-listing APIs	done	high	\N	2026-02-13 17:25:58.488264	\N
77	4	Build static frontend with Leaflet map	projects/adult-directory/index.html + style.css + app.js	done	high	\N	2026-02-13 17:25:58.515009	\N
78	4	Add Claude-powered 'Add Listing' via URL parsing	Anthropic API integration in server.py	done	medium	\N	2026-02-13 17:25:58.536585	\N
79	4	Add social media fields to listings	Instagram, Twitter, website fields	done	medium	\N	2026-02-13 17:25:58.560054	\N
80	4	Improve image scraping	projects/adult-directory/tools/scrape-images.py	done	medium	\N	2026-02-13 17:25:58.583026	\N
81	4	Deploy to Ubuntu server (port 3000)	http://192.168.68.139:3000 — systemd service enabled	done	high	\N	2026-02-13 17:25:58.606305	\N
82	4	Create GitHub repo	github.com/Windsor/adult-directory-portugal (private)	done	medium	\N	2026-02-13 17:25:58.626503	\N
83	4	Set up systemd service	adult-directory.service — auto-starts on reboot	done	medium	\N	2026-02-13 17:25:58.660822	\N
84	4	Add Anthropic API key to server	AI 'Add Listing' feature disabled without key	todo	low	\N	2026-02-13 17:25:58.698394	\N
85	4	Fix JS-rendered site scraping	WordPress/Divi sites like Natura Spa can't be scraped statically	todo	low	\N	2026-02-13 17:25:58.726562	\N
87	5	Build Flask + PostgreSQL backend	projects/project-tracker/server.py — CRUD for projects, tasks, updates	done	high	\N	2026-02-13 17:25:58.772171	\N
88	5	Build dashboard frontend	projects/project-tracker/index.html — Big Picture, Kanban, Project Board views	done	high	\N	2026-02-13 17:25:58.798612	\N
89	5	Deploy to Ubuntu server (port 3001)	http://192.168.68.139:3001 — systemd service	done	high	\N	2026-02-13 17:25:58.821446	\N
90	5	Set up systemd service	project-tracker.service — auto-starts on reboot	done	medium	\N	2026-02-13 17:25:58.858544	\N
91	5	Populate with all projects and artifacts	8 projects with full task lists and status updates	done	medium	\N	2026-02-13 17:25:58.895695	\N
92	6	Build core game — 83 cards, 5 levels	projects/escalate/index.html — single HTML file	done	high	\N	2026-02-13 17:25:58.932964	\N
93	6	Dice mechanic	Integrated into game flow	done	medium	\N	2026-02-13 17:25:58.971581	\N
94	6	Timer mechanic	Configurable countdown timer	done	medium	\N	2026-02-13 17:25:59.00922	\N
95	6	Voting system	Group voting for challenges	done	medium	\N	2026-02-13 17:25:59.047283	\N
96	6	Gender/orientation matching	Players set preferences, cards adapt	done	medium	\N	2026-02-13 17:25:59.084502	\N
97	6	Stripping mechanic	Progressive clothing removal tied to levels	done	medium	\N	2026-02-13 17:25:59.124592	\N
98	6	Deploy publicly or share	Not yet hosted anywhere	todo	low	\N	2026-02-13 17:25:59.153075	\N
99	7	Build dashboard script	tools/samsung-frame/dashboard.py — Pillow image generation	done	high	\N	2026-02-13 17:25:59.176967	\N
100	7	Create LaunchAgent	com.openclaw.frame-dashboard.plist — runs every 15 min	done	medium	\N	2026-02-13 17:25:59.212549	\N
101	7	Fix Pillow import issue	Resolved dependency path	done	medium	\N	2026-02-13 17:25:59.235887	\N
102	7	Update TV IP to 192.168.68.151	Was wrong IP, updated	done	medium	\N	2026-02-13 17:25:59.271847	\N
103	7	Data sources: weather, crypto, markets, news	Open-Meteo, CoinGecko, Yahoo Finance, NYT RSS	done	medium	\N	2026-02-13 17:25:59.308507	\N
105	8	Genre analysis — 3 dark romance bestsellers	projects/cruel-obsession/genre-analysis.md — Lipińska, Douglas, Huang	done	high	\N	2026-02-13 17:25:59.358696	\N
106	8	Write full novella	projects/cruel-obsession/cruel-obsession.md — Aleksandr Volkov + Sofia Marques, Lisbon setting	done	high	\N	2026-02-13 17:25:59.383409	\N
71	3	Glenn picks final cover (likes A doorway + C variants)	Awaiting final selection	done	high	\N	2026-02-13 17:25:58.370293	2026-02-13 17:27:38.941011
104	7	Re-enable LaunchAgent	Paused per Glenn's request — unloaded	done	low	\N	2026-02-13 17:25:59.333751	2026-02-13 18:07:33.856029
113	4	Set up GitHub Git auto-deploy on Hostinger		done	medium	\N	2026-02-13 20:05:23.670181	\N
114	4	Push static deploy build to GitHub repo		done	medium	\N	2026-02-13 20:05:23.72506	\N
86	4	Deploy to public domain	Hostinger or custom domain — deferred	done	medium	\N	2026-02-13 17:25:58.751549	2026-02-13 20:05:34.343216
107	4	Redesign frontend — dark theme, hero section, card grid	Complete rewrite: index.html, style.css, app.js — dark theme matching project tracker, hero with search, card hover effects, detail modals	done	high	\N	2026-02-13 18:07:12.696561	\N
108	4	Add worldwide support — country/region fields	Added country and countryCode to all 40 listings in data/listings.json	done	high	\N	2026-02-13 18:07:12.733355	\N
109	4	Add search & filter — category, country, city	Sticky filter bar with category pills, country dropdown, dynamic city dropdown, text search	done	high	\N	2026-02-13 18:07:12.768705	\N
110	4	Add map/grid view toggle	Dark CartoDB map tiles, toggle between grid and map view	done	medium	\N	2026-02-13 18:07:12.805845	\N
111	4	Responsive/mobile-first layout	Breakpoints at 768px and 480px	done	medium	\N	2026-02-13 18:07:12.847308	\N
112	4	Redeploy redesigned version	Deployed to r2d2:3000, pushed to GitHub	done	high	\N	2026-02-13 18:07:12.889149	\N
115	4	Configure Hostinger SSH key for private repo access		done	medium	\N	2026-02-13 20:05:23.780979	\N
116	4	Verify site is live at directory.thriftyexplorations.com		todo	medium	\N	2026-02-13 20:05:23.841182	\N
117	9	Flask backend + SQLite models		done	medium	\N	2026-02-14 14:13:02.67176	2026-02-14 14:26:50.739526
118	9	Web UI (dark theme, quiz editor, settings)		done	medium	\N	2026-02-14 14:13:02.734776	2026-02-14 14:26:54.893629
119	9	Video generation pipeline (ffmpeg + Pillow)		done	medium	\N	2026-02-14 14:13:02.796215	2026-02-14 14:26:54.946573
120	9	ElevenLabs TTS integration		done	medium	\N	2026-02-14 14:13:02.854657	2026-02-14 14:26:54.995299
121	9	Sample quiz data (geography, movies)		done	medium	\N	2026-02-14 14:13:02.915384	2026-02-14 14:26:55.040978
122	9	Ubuntu deployment (systemd, nginx, setup.sh)		done	medium	\N	2026-02-14 14:13:02.975324	2026-02-14 14:26:55.088642
123	9	Deploy to Ubuntu server (r2d2)		done	medium	\N	2026-02-14 14:21:54.266195	2026-02-14 14:26:55.135295
124	10	Legal & regulatory research	ERC registration, business structure, copyright, GDPR, tax, defamation law research completed	done	medium	\N	2026-02-18 08:42:40.296004	\N
125	10	Business plan	Mission, audience, content strategy, revenue model, 3-year projections	done	medium	\N	2026-02-18 08:42:40.359246	2026-02-18 08:44:45.769569
126	10	Tech stack evaluation	Ghost vs Substack vs Beehiiv comparison, launch setup, GDPR compliance	done	medium	\N	2026-02-18 08:42:40.422543	2026-02-18 08:44:45.827942
127	10	Ghost CMS server setup	Installing Ghost, MySQL, Caddy, cloudflared on Ubuntu server	done	medium	\N	2026-02-18 10:20:57.871423	2026-02-18 10:32:15.117688
128	10	Daily content automation	Morning (7am) + Afternoon (2pm) cron jobs creating 6-10 feature articles, daily briefing, and markets/biz/tech briefing as drafts. Ghost publish script at tools/ghost-publisher/publish.py	done	medium	\N	2026-02-18 15:13:04.809142	\N
131	10	Stripe payments setup	Connect Stripe for paid subscriptions (€8/mo or €80/yr)	todo	medium	\N	2026-02-18 15:13:04.993179	\N
132	10	Set Up Twitter/X Account	1. Go to x.com and create account for @ThePortugalBrief\n2. Use the rooster avatar (same as Bluesky)\n3. Bio: "Daily English-language news and analysis for Portugal expats. Politics, markets, immigration, culture."\n4. Link: theportugalbrief.pt\n5. After creation, go to developer.x.com and apply for API access (Free tier: 1,500 tweets/month)\n6. Create a Project + App, get API Key, API Secret, Access Token, Access Token Secret\n7. Send all 4 keys to Saturday for social-poster integration\n\nNote: Twitter Free API tier allows posting only. If it requires $200/mo Basic plan, skip and revisit later.	todo	medium	\N	2026-02-19 11:33:57.731131	\N
133	10	Set Up LinkedIn Page	1. Go to linkedin.com/company/setup/new and create a Company Page\n2. Name: The Portugal Brief\n3. Use the rooster avatar as logo\n4. Tagline: "Daily English-language news for Portugal expats"\n5. Website: theportugalbrief.pt\n6. Industry: Online Media\n7. For API access: Go to linkedin.com/developers, create an app linked to the Company Page\n8. Request Marketing API access (needed for posting)\n9. OAuth2 flow required — Saturday has a helper script at tools/social-poster/linkedin_oauth.py\n10. Send Client ID, Client Secret, and the Access Token to Saturday\n\nNote: LinkedIn API approval can take a few days.	todo	low	\N	2026-02-19 11:33:57.782524	\N
134	10	Set Up Facebook Page	1. Go to facebook.com/pages/create\n2. Category: News & Media Website\n3. Name: The Portugal Brief\n4. Use rooster avatar as profile picture\n5. Cover photo: generate one via Midjourney or use a Portugal landscape\n6. About: Daily English-language news for expats in Portugal\n7. Link: theportugalbrief.pt\n8. For auto-posting: Create a Facebook App at developers.facebook.com\n9. Get Page Access Token with pages_manage_posts permission\n10. Send Page ID and Access Token to Saturday\n\nNote: Facebook auto-posting is optional — many newsletters skip it and just share manually.	todo	low	\N	2026-02-19 11:33:57.829113	\N
135	10	Set Up Instagram Account	1. Create Instagram account @theportugalbrief\n2. Convert to Professional/Business account\n3. Link to Facebook Page (required for API posting)\n4. Use rooster avatar\n5. Bio: "Portugal news for expats 🇵🇹 | Daily briefings, analysis & guides"\n6. Link in bio: theportugalbrief.pt\n7. Instagram API requires Facebook Business connection for auto-posting\n8. Strategy: Post article quote cards (image with headline overlay) rather than link posts\n\nNote: Instagram doesn't support link posts natively. Best used with visual content. Lower priority than text-based platforms.	todo	low	\N	2026-02-19 11:33:57.876198	\N
136	10	Add Bluesky Link to Ghost Settings	Go to Ghost Admin → Settings → General → Social accounts.\nReplace the Twitter/X field with: https://bsky.app/profile/theportugalbrief.bsky.social\nClear the Facebook field (or add when FB page is created).	todo	high	\N	2026-02-19 11:33:57.922225	\N
141	10	SEO: Google Search Console setup (needs Glenn for domain verification)		blocked	medium	\N	2026-02-19 23:05:57.418972	\N
142	10	Backup system: daily automated backups on r2d2 (Ghost, PT, Quiz, Social)		done	medium	\N	2026-02-19 23:09:06.143007	\N
143	10	Infrastructure monitoring: health checks every 30 min		done	medium	\N	2026-02-19 23:09:06.202991	\N
144	10	publish.py refactored: retry logic, auto meta descriptions, better docs		done	medium	\N	2026-02-19 23:09:06.263844	\N
137	10	SEO: Meta descriptions added to all 20 posts		done	medium	\N	2026-02-19 23:05:57.246494	2026-02-20 01:02:42.332676
138	10	Image library expanded to 38 verified URLs		done	medium	\N	2026-02-19 23:05:57.294536	2026-02-20 01:02:42.378739
139	10	Social poster: retry logic + stats endpoint		done	medium	\N	2026-02-19 23:05:57.342232	2026-02-20 01:02:42.424916
140	10	READMEs added to all tools/ directories		done	medium	\N	2026-02-19 23:05:57.387858	2026-02-20 01:02:42.469725
145	10	Automated daily backups (Ghost DB, Project Tracker, Quiz Gen, Social Poster)		done	high	\N	2026-02-20 01:02:42.509486	\N
146	10	Infrastructure health monitoring (30-min checks, 4 services)		done	medium	\N	2026-02-20 01:02:42.535802	\N
147	10	publish.py refactored with retry logic and auto meta_description		done	medium	\N	2026-02-20 01:02:42.563851	\N
148	10	Project Tracker dashboard upgrade (search, activity feed, analytics)		done	medium	\N	2026-02-20 01:02:42.591015	\N
149	10	About page + Tag SEO + Site meta tags + Navigation		done	medium	\N	2026-02-20 01:07:54.64526	\N
150	10	Newsletter analytics script (analytics.py)		done	low	\N	2026-02-20 01:07:54.67276	\N
151	10	Content templates (6 article types + style guide)		done	low	\N	2026-02-20 01:07:54.69894	\N
152	10	Git repo initialized for Project Tracker		done	medium	\N	2026-02-20 03:03:58.428074	\N
153	10	Cron job monitoring script + docs		done	medium	\N	2026-02-20 03:03:58.493582	\N
154	10	Old memory files archived (week 1+2 summaries)		done	low	\N	2026-02-20 03:03:58.552871	\N
155	10	Ghost custom redirects (subscribe, tags, rss)		done	medium	\N	2026-02-20 03:03:58.610522	\N
156	10	Mastodon social poster module (ready, needs credentials)		done	low	\N	2026-02-20 03:03:58.676487	\N
130	10	Mailgun email setup	Configure Mailgun for newsletter email delivery (EU region, SPF/DKIM/DMARC)	in_progress	medium	\N	2026-02-18 15:13:04.932668	\N
129	10	Domain + Cloudflare Tunnel	Waiting on Glenn to get .pt domain. Then set up Cloudflare Tunnel for public access.	done	medium	\N	2026-02-18 15:13:04.871838	2026-02-20 16:12:56.344339
157	11	Ghost CMS Setup	Installed Ghost v6.19.2 on port 2370, DB ghost_finance, systemd service ghost-finance	done	high	\N	2026-02-20 23:10:08.916642	\N
158	11	Data Pipeline	CoinGecko crypto + Yahoo Finance equities/forex/commodities/bonds + Fear & Greed index	done	high	\N	2026-02-20 23:10:08.977276	\N
159	11	Daily Pulse Template	Full HTML template with tables for all asset classes, top movers, Fear & Greed gauge	done	high	\N	2026-02-20 23:10:09.035638	\N
160	11	Publish Script	publish.py with --draft/--dry-run/--data-only modes, retry logic for CoinGecko rate limits	done	high	\N	2026-02-20 23:10:09.097098	\N
161	11	Daily Cron Job	7am Lisbon daily publish via OpenClaw cron	done	high	\N	2026-02-20 23:10:09.157767	\N
162	11	First Live Edition	Daily Pulse Feb 20 2026 published successfully	done	high	\N	2026-02-20 23:10:09.220512	\N
163	9	Geography Generator v2	Complete visual overhaul: dark navy palette, subtle land fill, multiple choice options (A/B/C/D), improved counter badge, thicker timer with seconds, regional distractors	done	high	\N	2026-02-20 23:25:34.777164	\N
164	9	Batch Generation System	batch_geography.py with 7 preset quizzes (easy/medium/hard), multi-format support, curated country lists	done	high	\N	2026-02-20 23:25:34.81974	\N
165	9	9:16 Portrait Layout	Vertical layout for Shorts/TikTok/Reels with stacked options, larger touch targets	done	high	\N	2026-02-20 23:25:34.859303	\N
167	9	Capital Cities Quiz Generator	New quiz type showing country on map asking for capital. 147 capitals DB, amber branding.	done	high	\N	2026-02-21 03:09:43.656032	\N
168	9	Capital Cities Batch Scripts	batch_capitals.py — 7 preset quizzes across easy/medium/hard difficulties.	done	high	\N	2026-02-21 03:09:43.695578	\N
169	9	Branded Intro/Outro Clips (8 total)	Remotion animated clips: geography (green) + capitals (amber), 16:9 + 9:16.	done	medium	\N	2026-02-21 03:09:43.732918	\N
170	9	Intro/Outro Concatenation Scripts	add_intros.sh + batch_add_intros.sh for adding channel branding to videos.	done	medium	\N	2026-02-21 03:09:43.767782	\N
172	9	Channel Content Documentation	CHANNEL_README.md — complete guide for the quiz channel content pipeline.	done	medium	\N	2026-02-21 03:09:43.838454	\N
166	9	Initial Content Batch	7 quizzes generating in YouTube + Shorts formats — ~20+ videos for channel launch	done	high	\N	2026-02-20 23:25:34.89546	2026-02-21 03:09:43.872307
171	9	Capital Cities Video Generation	7 quiz sets generating: 14+ videos with Shorts splits.	done	high	\N	2026-02-21 03:09:43.803871	2026-02-21 05:01:56.247984
173	10	Fix backup script — MySQL/PG credentials broken (all backups were empty)		done	high	\N	2026-02-21 23:04:03.693017	\N
174	10	Fix social-poster crash loop (7726 restarts, port conflict)		done	high	\N	2026-02-21 23:04:03.747798	\N
175	10	Add sudoers entry for passwordless pg_dump backups		done	medium	\N	2026-02-21 23:04:03.796785	\N
176	11	Sync publish.py from r2d2 (pulse-only, analysis-only, deep-only modes)		done	low	\N	2026-02-21 23:04:03.845372	\N
177	11	AI Analysis Generator		done	high	\N	2026-02-21 23:12:49.86067	\N
178	11	Premium Deep Dive (Paid Tier)		done	high	\N	2026-02-21 23:12:49.909501	\N
179	11	Video Pipeline v2 (Report Cards)		done	medium	\N	2026-02-21 23:12:49.946022	\N
180	11	Video Pipeline v3 (YouTube Clips)		done	high	\N	2026-02-21 23:12:49.984746	\N
181	11	Crossfade Transitions		done	low	\N	2026-02-21 23:12:50.022722	\N
182	11	Publisher Logging & Error Handling		done	medium	\N	2026-02-21 23:12:50.059008	\N
185	11	Auto-upload YouTube/TikTok		todo	medium	\N	2026-02-21 23:12:50.166162	\N
186	11	Stripe Payment Integration		todo	high	\N	2026-02-21 23:12:50.202469	\N
187	11	FRED API Key Registration		todo	low	\N	2026-02-21 23:12:50.242144	\N
188	9	Brand all quiz videos with intro/outro (79 videos: 65 geo + 14 capitals)		done	medium	\N	2026-02-21 23:34:55.221119	\N
189	10	Weekly Digest Generator	Auto-compiles top articles into Sunday roundup, cron every Sunday 10am	done	medium	\N	2026-02-22 01:05:29.789479	\N
190	10	First Weekly Digest Published	Feb 15-22 digest: 42 articles, 6 themes, live at /weekly-digest-15-february-to-22-february-2026/	done	medium	\N	2026-02-22 01:05:29.84351	\N
191	10	Health check script v2	Added systemd checks, backup freshness, fixed awk quoting for cron	done	low	\N	2026-02-22 01:05:36.835111	\N
192	10	Backup cleanup - removed empty files	Cleaned 7 empty backup files from pre-fix era, verified new backups working	done	low	\N	2026-02-22 01:05:36.886894	\N
193	10	Memory archival - week 3	Archived Feb 14-16 to archive/, created week3 summary	done	low	\N	2026-02-22 01:05:36.934531	\N
194	10			done	medium	\N	2026-02-22 03:04:47.969218	\N
195	10			done	medium	\N	2026-02-22 03:04:48.048981	\N
196	10			done	medium	\N	2026-02-22 03:04:48.127025	\N
197	10			done	medium	\N	2026-02-22 03:04:48.182707	\N
198	10			done	medium	\N	2026-02-22 03:04:48.27654	\N
199	10	Logrotate for health/backup/cleanup logs		done	medium	\N	2026-02-22 03:04:51.558133	\N
200	10	Social poster systemd hardening (crash loop prevention)		done	high	\N	2026-02-22 03:04:57.008235	\N
201	10	Ghost content audit: custom excerpts for 37/43 posts		done	medium	\N	2026-02-22 03:04:57.053037	\N
202	10	Content audit script (content-audit.py)		done	low	\N	2026-02-22 03:04:57.097853	\N
203	10	Offsite backup download to Mac mini		done	high	\N	2026-02-22 03:04:57.125269	\N
204	11	Finance Clip Pipeline - Video Generation	Automated daily market commentary video generation with MoviePy. Creates landscape (16:9) and shorts (9:16) versions. Runs via cron at 7:20am.	done	medium	\N	2026-02-22 04:04:07.127571	\N
207	11	Clip pipeline: Auto-cleanup script	Removes clips/output/cache older than 3 days. Added to r2d2 crontab at 6am daily.	done	low	\N	2026-02-22 04:04:07.305132	\N
208	11	TTS voiceover for clip pipeline	Added edge-tts (Microsoft Neural voices) for AI narration on commentary cards. Voice: en-US-AndrewNeural. Duration auto-adjusts to speech length. Background ambient music bed via ffmpeg synthesis. Fixed concat audio loss bug. CLI flags: --no-tts, --no-music.	done	high	\N	2026-02-22 23:13:18.043628	\N
209	11	Background music for clip pipeline	Ambient pad synthesized via ffmpeg (layered sine waves, lowpass filtered). Mixed under TTS voice at appropriate levels. Auto fade-in/out.	done	medium	\N	2026-02-22 23:13:25.000946	\N
183	11	TTS Voiceover for Videos		done	high	\N	2026-02-21 23:12:50.094605	2026-02-22 23:50:03.324637
184	11	Background Music Layer		done	medium	\N	2026-02-21 23:12:50.130802	2026-02-22 23:50:06.505743
205	11	Clip pipeline: Add TTS voiceover	Add AI narration to commentary cards instead of just text overlays	done	medium	\N	2026-02-22 04:04:07.187355	2026-02-22 23:50:06.558181
206	11	Clip pipeline: Add background music	Subtle financial news music bed under commentary cards	done	low	\N	2026-02-22 04:04:07.245624	2026-02-22 23:50:06.607156
210	11	Enhanced verify_publish.py with content quality checks	Checks HTML length, feature images, excerpts, tags, visibility. --json output. Better error handling.	done	medium	\N	2026-02-23 01:04:59.496692	\N
211	11	data_pipeline.py code quality hardening	Specific exception handling, weekend/holiday awareness (5d yfinance), server error retries, None filtering, data quality logging.	done	medium	\N	2026-02-23 01:04:59.594492	\N
212	11	macro_data.py error handling improvements	FRED rate limit handling, connection error early-exit, timeout-specific handling, DefiLlama status check, better logging.	done	medium	\N	2026-02-23 01:04:59.674513	\N
213	11	Added verification step to finance cron pipeline	Finance Daily Pulse cron now runs verify_publish.py --json as Step 5 after publishing.	done	medium	\N	2026-02-23 01:04:59.742738	\N
214	10	Batch fix: added custom_excerpts to 15 posts	Fixed all posts missing custom_excerpt via Admin API. Updated publish.py to auto-generate excerpts for future posts.	done	medium	\N	2026-02-23 01:04:59.807921	\N
215	10	Portugal Brief content audit - all 15 recent posts verified (images, excerpts, meta OK)		done	medium	\N	2026-02-23 03:04:06.470677	\N
216	10	Social poster verified healthy - 6/6 Bluesky cross-posts successful		done	low	\N	2026-02-23 03:04:06.525041	\N
217	11	READMEs added to finance-publisher, social-poster, finance-clip-pipeline on r2d2		done	medium	\N	2026-02-23 03:04:06.574357	\N
218	11	Git repos initialized for finance-publisher and social-poster on r2d2		done	medium	\N	2026-02-23 03:04:06.623889	\N
219	11	Fix verify_publish.py formats=html bug	Admin API was not returning HTML content because formats=html parameter was missing. Verification was reporting 0 chars for all posts. Fixed and committed.	done	high	\N	2026-02-23 23:05:37.922509	\N
220	10	Expand image library 38→56 verified images	Added 18 new verified Unsplash images covering: military/defense, education, EU/Europe, immigration, construction/housing, energy/climate, sports, agriculture, politics/protest, trade/shipping, Madeira, Fado music.	done	medium	\N	2026-02-23 23:05:37.975601	\N
221	10	Add duplicate detection to Ghost publisher	publish.py now checks for existing posts with same title before publishing. Prevents duplicate articles. Also created todays_titles.py helper script.	done	high	\N	2026-02-23 23:05:38.024172	\N
222	10	Improve AM/PM cron prompts - dedup + dynamic image library	Morning and afternoon crons now reference image-library.md file instead of hardcoded images. Afternoon cron runs todays_titles.py first to check for duplicate stories.	done	medium	\N	2026-02-23 23:05:38.072654	\N
223	11	Finance newsletter: fix 9 missing custom excerpts across all posts		done	medium	\N	2026-02-24 01:03:55.495208	\N
224	11	Finance newsletter: fix 3 missing feature images (Daily Pulse Feb 20-22)		done	medium	\N	2026-02-24 01:03:55.513668	\N
225	11	Finance publisher: add file-based caching layer (cache.py) for CoinGecko rate limit resilience		done	high	\N	2026-02-24 01:03:55.546517	\N
226	11	Finance publisher: integrate caching into data_pipeline.py and publish.py		done	high	\N	2026-02-24 01:03:55.567342	\N
227	10	Portugal Brief: add descriptions + meta to 7 tags (Housing, Tech, Health, Tourism, Climate, Football, Finance)		done	medium	\N	2026-02-24 01:03:55.601407	\N
228	10	Portugal Brief: content quality audit — 30 posts analyzed, no duplicates, healthy distribution		done	low	\N	2026-02-24 01:03:55.637321	\N
229	10	Consolidate duplicate tags (daily-briefing, markets-briefing)		done	medium	\N	2026-02-24 03:03:11.747358	\N
230	10	Add descriptions to 7 more tags (Afternoon Update, Environment, Expat Life, etc.)		done	low	\N	2026-02-24 03:03:11.793559	\N
231	10	Memory maintenance: archive old files, update MEMORY.md		done	low	\N	2026-02-24 03:03:11.839091	\N
232	10	Offsite backup pull (Feb 24 - all 5 DBs)		done	medium	\N	2026-02-24 03:03:11.885363	\N
233	11	Night shift Block 4 — Final health check & wrap-up	All 5 services active, disk 90%, 9.2GB RAM free, no errors in last 3 hours. Clean wrap-up of 4-block night shift.	done	low	\N	2026-02-24 05:00:26.99897	\N
234	11	Fixed 2 missing custom_excerpts on finance newsletter (Deep Dive + Market Analysis)		done	medium	\N	2026-02-24 23:04:58.828911	\N
235	11	Added auto-fix for missing excerpts in verify_publish.py		done	high	\N	2026-02-24 23:04:58.881871	\N
236	10	Deleted 4 duplicate articles from Portugal Brief (Feb 20-23)		done	medium	\N	2026-02-24 23:04:58.929463	\N
237	10	Full content audit: 76 PT Brief posts + 14 Finance posts — all healthy		done	low	\N	2026-02-24 23:04:58.975248	\N
238	10	Tag hygiene: fixed 6 post assignments, deleted 8 empty/duplicate tags		done	medium	\N	2026-02-24 23:07:37.257803	\N
239	10	Added descriptions to 25 remaining Portugal Brief tags		done	low	\N	2026-02-24 23:07:37.31282	\N
240	10	Enhanced publish.py dedup with keyword similarity detection		done	high	\N	2026-02-24 23:07:37.361202	\N
241	10	SEO: Added meta_title + og_title to all 71 PT Brief posts		done	high	\N	2026-02-25 01:05:22.726679	\N
242	11	SEO: Added meta_title + og_title to all 14 Finance posts		done	high	\N	2026-02-25 01:05:22.76297	\N
243	10	SEO: Auto-set meta_title/og_title/og_description in ghost-publisher		done	high	\N	2026-02-25 01:05:22.798817	\N
244	11	Cross-promotion: Added PT Brief link to finance newsletter footer		done	medium	\N	2026-02-25 01:05:22.834765	\N
245	10	SEO/Growth audit document created (projects/seo-growth-audit.md)		done	medium	\N	2026-02-25 01:05:22.870666	\N
246	10	Night shift Feb 25 Block 4: Final health check + MEMORY.md review + wrap up		done	medium	\N	2026-02-25 05:00:53.592506	\N
247	11	Sparklines + anti-aliased gauge on video V2		done	medium	\N	2026-02-26 01:15:25.216967	\N
248	10	Subscribe CTAs injected into all posts + member growth tools		done	medium	\N	2026-02-26 01:15:25.277344	\N
249	11	Subscribe CTAs injected into finance posts + meta fix		done	medium	\N	2026-02-26 01:15:25.336952	\N
250	11	verify_publish.py: auto-fix meta fields + paid post excerpt fallback	Enhanced verify_publish.py to auto-fix missing meta_title, og_title, og_description after publish. Added fallback for paid/members-only posts with empty HTML (uses title as excerpt). Fixed 2 finance posts missing meta fields.	done	medium	\N	2026-02-26 23:07:24.695818	\N
251	10	Night shift Feb 27: health check + offsite backup + content audit	All services running. Disk 90%, 9.1GB RAM. 95 PT Brief + 20 Finance posts all healthy. Offsite backups pulled (PT 863KB, Finance 370KB). Social poster 30/30 Bluesky posts. Archived Feb 23-24 daily memory files.	done	low	\N	2026-02-26 23:07:24.757743	\N
252	5	Systemd migration: PT, QG, SP services	Migrated 3 standalone processes to systemd service units. Auto-restart on crash, survive reboots, proper journald logging.	done	high	\N	2026-02-27 01:03:59.500257	\N
253	5	Health check v2: proper systemd + load monitoring	Fixed health-check.sh to check all 5 systemd services, added load average monitoring, removed broken process pattern matching.	done	medium	\N	2026-02-27 01:03:59.553714	\N
254	5	Weekly performance report generator	Created tools/weekly-report.py: newsletter KPIs (content, members, social, health). Supports --json for automation.	done	medium	\N	2026-02-27 01:03:59.602816	\N
255	5	Live health API + services dashboard	Added /api/health endpoint to project tracker (real-time service/disk/memory checks). Updated services.html with auto-refreshing dark-mode dashboard.	done	medium	\N	2026-02-27 01:08:11.932745	\N
256	5	Health check v3 — fixed false positives	Replaced broken systemd checks with port-based process detection for Ghost. All 5 services now correctly detected.	done	medium	\N	2026-02-27 03:08:39.987838	\N
257	5	Process supervisor — auto-restart crashed services	process-supervisor.sh runs every 5min via cron. Checks all 5 services by HTTP, auto-restarts if down. Logs to supervisor.log.	done	high	\N	2026-02-27 03:08:40.042747	\N
258	5	Email deliverability checker	email-deliverability-check.py checks SPF/DKIM/DMARC. Found: PT Brief missing DKIM (critical), SPF softfail, DMARC monitoring-only.	done	medium	\N	2026-02-27 03:08:40.092998	\N
259	5	Content publishing calendar tool	content-calendar.py shows posts, patterns by weekday, gap detection, daily averages for both newsletters.	done	medium	\N	2026-02-27 03:08:40.140044	\N
311	10	Cross-linking: 3 new guides with Related Guides sections	Added internal links to Algarve, Education, and Salary guides.	done	medium	\N	2026-03-02 03:06:10.834173	\N
260	10	Night Shift Feb 27 — Final health check + wrap-up	Block 4: All 5 services healthy, disk 88%, 9.1GB RAM. Tonight completed: systemd migration, health check v2/v3, process supervisor, email deliverability audit, content calendar tool, weekly report generator, live health API + services dashboard. 12 tasks across 4 blocks.	done	low	\N	2026-02-27 05:00:20.032775	\N
261	10	Social distribution: tagged 57 PT Brief posts for Bluesky cross-posting		done	high	\N	2026-02-27 23:09:48.149648	\N
262	10	Bluesky profile: added display name, description, followed 10 relevant accounts		done	medium	\N	2026-02-27 23:09:48.209859	\N
263	10	Social poster: dynamic hashtags based on post tags, content performance analyzer		done	medium	\N	2026-02-27 23:09:48.271833	\N
264	11	verify_publish.py: fixed Deep Dive meta auto-fix (was skipping paid posts), added meta_description fix		done	high	\N	2026-02-27 23:09:48.333663	\N
265	10	Social poster: dedup protection prevents double-posting from webhook retries, deleted 1 Bluesky dupe		done	medium	\N	2026-02-27 23:13:11.150118	\N
266	10	Bluesky analytics tracker: daily follower/engagement logging, cron at 10pm UTC		done	medium	\N	2026-02-27 23:13:11.211283	\N
267	10	Content performance analyzer: word count, tag distribution, social coverage, publishing patterns		done	medium	\N	2026-02-27 23:13:11.271489	\N
268	5	Fixed social-poster systemd conflict	Process supervisor spawned standalone gunicorn conflicting with systemd. Killed rogue PIDs, updated supervisor to use systemctl restart for migrated services.	completed	high	\N	2026-02-28 01:07:58.039917	\N
269	10	Weekly digest cron automation	Set up automatic weekly digest publishing every Sunday 9am UTC via cron. Selects top 10 stories by importance score.	completed	medium	\N	2026-02-28 01:07:58.068026	\N
270	10	Newsletter sender name configured	Set sender_name on both Ghost newsletters. Portal button needs Owner API (blocked).	completed	medium	\N	2026-02-28 01:07:58.091176	\N
271	10	Growth dashboard tool	Created growth-dashboard.py: member counts, growth rate, content volume, tag distribution, recommendations for both newsletters.	completed	medium	\N	2026-02-28 01:07:58.118925	\N
272	5	Health endpoint newsletter stats	Added member counts and post totals for both newsletters to /api/health endpoint on Project Tracker.	completed	low	\N	2026-02-28 01:07:58.146752	\N
273	10	Newsletter growth plan document	Created comprehensive growth plan covering portal signup, DKIM, Stripe, newsletter directories, Reddit, social expansion, and content strategy.	completed	medium	\N	2026-02-28 01:07:58.176691	\N
274	5	Growth dashboard weekly cron	Set up Monday 8am UTC cron for growth dashboard report.	completed	low	\N	2026-02-28 01:07:58.204681	\N
275	10	JSON-LD structured data — all 106 PT Brief posts		done	medium	\N	2026-02-28 03:07:00.735715	\N
276	10	OG meta optimization: 51 titles + 90 descriptions fixed		done	medium	\N	2026-02-28 03:07:09.687623	\N
277	10	Social preview validator tool		done	medium	\N	2026-02-28 03:07:09.74084	\N
278	10	Content freshness audit tool		done	medium	\N	2026-02-28 03:07:09.790762	\N
279	10	Link checker tool		done	medium	\N	2026-02-28 03:07:09.838546	\N
280	10	PT Brief publish.py helper with JSON-LD auto-gen		done	medium	\N	2026-02-28 03:07:09.886203	\N
281	11	JSON-LD structured data for all 23 Finance posts		done	medium	\N	2026-02-28 03:07:09.932713	\N
282	11	OG description optimization: 14 Finance posts fixed		done	medium	\N	2026-02-28 03:07:09.980986	\N
283	11	Finance publisher OG length limits enforced		done	medium	\N	2026-02-28 03:07:10.027274	\N
284	10	JSON-LD structured data injected into all 129 posts	NewsArticle schema added to codeinjection_head for 106 PT Brief + 23 Finance posts. Auto-generation added to both publishers.	done	high	\N	2026-02-28 05:00:26.9517	\N
285	10	OG meta optimization - fixed 155 oversized titles/descriptions	51 og:titles truncated to 70 chars, 104 og:descriptions to 200 chars. Limits enforced in publishers.	done	medium	\N	2026-02-28 05:00:27.012797	\N
286	10	Docker dangling volumes cleaned (137MB freed)	Removed 6 unused volumes from docmost, invidious, translation containers. Active containers untouched.	done	low	\N	2026-02-28 05:00:31.344484	\N
287	10	Night shift: Deploy Reddit cross-posting module to social-poster		done	high	\N	2026-03-01 23:10:55.092607	\N
288	10	Night shift: Publish Golden Visa 2026 guide to Ghost (draft)		done	high	\N	2026-03-01 23:10:55.145597	\N
289	10	Night shift: Write Cost of Living Portugal 2026 guide (~3,500 words)		done	high	\N	2026-03-01 23:10:55.194635	\N
290	10	Night shift: Write Digital Nomad Visa D8 2026 guide (~3,500 words)		done	high	\N	2026-03-01 23:10:55.242078	\N
291	10	Night shift: Offsite backup (Mar 1) + manual backup run		done	medium	\N	2026-03-01 23:10:55.289887	\N
292	10	Night shift: Install praw on r2d2 for Reddit integration		done	low	\N	2026-03-01 23:10:55.338262	\N
293	10	Night shift: Write Buying Property in Portugal 2026 guide (~3,800 words)		done	high	\N	2026-03-01 23:14:11.914613	\N
294	10	Night shift: Create reusable publish-guide.py script on r2d2		done	medium	\N	2026-03-01 23:14:11.968543	\N
295	10	NHR Tax Portugal 2026 evergreen guide (~4,000 words) published as draft		done	high	\N	2026-03-02 01:08:41.081677	\N
296	10	Healthcare Portugal 2026 evergreen guide (~4,500 words) published as draft		done	high	\N	2026-03-02 01:08:41.135309	\N
297	10	Retiring in Portugal 2026 evergreen guide (~4,500 words) published as draft		done	high	\N	2026-03-02 01:08:41.183421	\N
298	10	Real Estate Portugal 2026 evergreen guide (~4,200 words) published as draft		done	high	\N	2026-03-02 01:08:41.230832	\N
299	10	Portugal Taxes 2026 evergreen guide (~4,000 words) published as draft		done	high	\N	2026-03-02 01:08:41.278193	\N
300	10	Residency Permit Portugal 2026 evergreen guide (~4,500 words) published as draft		done	high	\N	2026-03-02 01:08:41.324594	\N
301	10	Portugal vs Spain 2026 comparison guide (~4,000 words) published as draft		done	high	\N	2026-03-02 01:08:41.370143	\N
302	10	Lisbon Neighborhoods 2026 guide (~3,000 words) published as draft		done	medium	\N	2026-03-02 01:11:40.484454	\N
303	10	Porto Neighborhoods 2026 guide (~2,500 words) published as draft		done	medium	\N	2026-03-02 01:11:40.563766	\N
304	10	Guides index page (/guides/) created as Ghost page (draft)		done	medium	\N	2026-03-02 01:11:40.633171	\N
305	10	Internal cross-linking between 7 guides (Related Guides sections)		done	medium	\N	2026-03-02 01:11:40.691293	\N
306	10	Batch guide publisher script (publish-batch.py) for Ghost Admin API		done	medium	\N	2026-03-02 01:11:40.755717	\N
307	10	Algarve Expat Guide 2026 (~4,000 words)	8 towns, costs, healthcare, property, daily life. Draft on Ghost.	done	medium	\N	2026-03-02 03:06:10.698071	\N
308	10	Education in Portugal Guide 2026 (~3,800 words)	Schools, international options, universities, homeschooling, costs. Draft on Ghost.	done	medium	\N	2026-03-02 03:06:10.73023	\N
309	10	Salary and Minimum Wage Guide 2026 (~3,500 words)	Minimum wage, sector salaries, tax brackets, net calculations. Draft on Ghost.	done	medium	\N	2026-03-02 03:06:10.769524	\N
310	10	Guides index page updated (17 guides)	Updated /guides/ page with all 17 categorized guides across 5 sections.	done	medium	\N	2026-03-02 03:06:10.803916	\N
312	10	SEO metadata for all 16 draft guides	Added meta_title, meta_description, custom_excerpt, and tags to all 16 evergreen guides.	done	medium	\N	2026-03-02 03:07:16.618354	\N
313	10	FAQ structured data (JSON-LD) for 7 guides	Added FAQPage schema with 3 FAQ items each to top guides for Google rich snippets.	done	medium	\N	2026-03-02 03:08:37.106675	\N
314	10	Guide publishing scheduler tool	Created schedule-guide-publishing.py — schedules 2 guides/week (Mon+Thu). Ready for Glenn approval.	done	medium	\N	2026-03-02 03:08:37.153636	\N
315	10	Social media content calendar (Mar-Apr 2026)	48 social posts mapped to 16 guide launches. Launch day + teaser + repost for each guide.	done	medium	\N	2026-03-02 03:09:27.053333	\N
316	10	Bluesky image card generator deployed	card_generator.py using Pillow: 1200x630 branded cards with dark bg, green accent, headline + excerpt + tag badge. Auto-generated for every new post via social poster.	done	medium	\N	2026-03-02 23:12:20.494207	\N
317	10	Bluesky growth automation script	bluesky-growth.py: searches 8 Portugal/expat terms, follows up to 15 new accounts + likes up to 20 posts per run. Cron at 11pm daily. First run: 15 follows, 20 likes.	done	medium	\N	2026-03-02 23:12:29.90238	\N
318	10	4 feature articles published to PT Brief	Bank accounts guide, housing crisis analysis, startup ecosystem overview, IRS reform 2026 — all live with JSON-LD, SEO meta, social tag.	done	high	\N	2026-03-02 23:12:29.95656	\N
319	10	Social poster: pass title/excerpt/tags to Bluesky	Updated app.py to pass article metadata through to post_to_bluesky() for richer image card generation.	done	low	\N	2026-03-02 23:12:30.005369	\N
320	10	Article: ECB March 2026 rate cut and Portuguese mortgages	Published feature article on ECB rate cut impact. ~900 words, JSON-LD, SEO meta. Auto-posted to Bluesky.	done	medium	\N	2026-03-03 03:10:05.559984	\N
321	10	Article: Seguro inauguration — new presidency and expats	Published feature on President Andre Seguros inauguration this week. ~1,100 words: presidency powers, housing/immigration/EU policy angles, expat implications. Bluesky posted.	done	medium	\N	2026-03-03 03:10:17.28467	\N
322	10	Article: Portugal tourism record 2025 — sustainability debate	31.8 million tourist record analysis. ~1,200 words: revenue vs costs, housing impact, water constraints, AL regulation, government strategy, expat angles. Bluesky posted.	done	medium	\N	2026-03-03 03:10:17.315462	\N
323	11	Finance Newsletter: sector rotation module (sector_analysis.py)	Built sector_analysis.py: 11 SPDR sector ETFs, 1d/5d/1m performance, risk-on/off signal, breadth %. Wired into analysis_generator.py — sector context in Claude prompt. Section 8 (Sector Rotation) added to newsletter structure.	done	medium	\N	2026-03-03 03:10:17.339198	\N
324	10	PT Brief: SNS Healthcare Reforms 2026 article published		done	medium	\N	2026-03-03 05:04:29.97659	\N
325	10	PT Brief: Spring 2026 Property Market article published		done	medium	\N	2026-03-03 05:04:30.055962	\N
326	10	Night shift Block 4 final backup & offsite pull		done	low	\N	2026-03-03 05:04:30.118558	\N
327	12	Register obsessivenutrition.com domain	Domain confirmed available Mar 3 2026. Register ASAP.	todo	high	\N	2026-03-03 23:13:00.134279	\N
328	12	Build website v1 — static HTML/CSS	Complete homepage, books page, about, blog index, and omega-3 article. Ready to deploy. See projects/obsessive-nutrition/website/	done	high	\N	2026-03-03 23:13:00.229505	\N
329	12	Deploy website to hosting	Options: GitHub Pages, Netlify, or r2d2 Nginx. See website/README.md	todo	high	\N	2026-03-03 23:13:00.315769	\N
330	12	Set up email list (ConvertKit or MailerLite)	Wire into subscribe form in js/main.js	todo	medium	\N	2026-03-03 23:13:00.379823	\N
331	12	Publish sardines and olive oil books on KDP	Books already written. Need KDP account and formatting.	todo	high	\N	2026-03-03 23:13:00.442891	\N
332	12	Write 2 more blog articles	fake-olive-oil.html and curcumin-bioavailability.html outlined in website/blog/	todo	medium	\N	2026-03-03 23:13:00.505184	\N
333	12	Create Amazon Associates account	Needed for affiliate links in blog posts and book recommendations	todo	medium	\N	2026-03-03 23:13:00.567931	\N
334	10	PT Brief: 3 articles published Mar 4 (rental prices, min wage, energy)	1. Portugal Rental Prices Drop from October Peak\n2. Portugal 920 Minimum Wage 2026\n3. Middle East Energy Prices Impact Portugal\nAll live on theportugalbrief.pt	done	medium	\N	2026-03-03 23:13:06.066497	\N
335	10	PT Brief: 3 articles published Mar 4 (rental, min wage, energy)		done	medium	\N	2026-03-03 23:13:08.645959	\N
336	13	Register obsessivenutrition.com domain		todo	high	\N	2026-03-03 23:17:26.272657	\N
337	13	Design brand identity — series name, covers, colour palette		todo	high	\N	2026-03-03 23:17:26.335626	\N
338	13	Build website (Ghost or static) with blog + book landing pages		todo	high	\N	2026-03-03 23:17:26.383582	\N
339	13	Set up KDP author page		todo	medium	\N	2026-03-03 23:17:26.43079	\N
340	13	Write Book 3 outline — Salmon		todo	medium	\N	2026-03-03 23:17:26.477293	\N
341	13	Set up email list + lead magnet (free chapter)		todo	medium	\N	2026-03-03 23:17:26.522983	\N
342	13	Plan affiliate/sponsorship strategy for site		todo	low	\N	2026-03-03 23:17:26.569225	\N
\.


--
-- Name: artifacts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.artifacts_id_seq', 46, true);


--
-- Name: commands_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.commands_id_seq', 8, true);


--
-- Name: projects_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.projects_id_seq', 13, true);


--
-- Name: status_updates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.status_updates_id_seq', 30, true);


--
-- Name: tasks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tasks_id_seq', 342, true);


--
-- Name: artifacts artifacts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.artifacts
    ADD CONSTRAINT artifacts_pkey PRIMARY KEY (id);


--
-- Name: commands commands_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.commands
    ADD CONSTRAINT commands_pkey PRIMARY KEY (id);


--
-- Name: projects projects_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_pkey PRIMARY KEY (id);


--
-- Name: status_updates status_updates_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.status_updates
    ADD CONSTRAINT status_updates_pkey PRIMARY KEY (id);


--
-- Name: tasks tasks_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_pkey PRIMARY KEY (id);


--
-- Name: artifacts artifacts_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.artifacts
    ADD CONSTRAINT artifacts_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE CASCADE;


--
-- Name: artifacts artifacts_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.artifacts
    ADD CONSTRAINT artifacts_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.tasks(id) ON DELETE SET NULL;


--
-- Name: status_updates status_updates_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.status_updates
    ADD CONSTRAINT status_updates_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE CASCADE;


--
-- Name: tasks tasks_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict BVF6l9XpfjNIoeceWrBQkBQy1FzaU9SyMFXK3a7B0SErmCtApCzdE7qjVoyZNMJ

